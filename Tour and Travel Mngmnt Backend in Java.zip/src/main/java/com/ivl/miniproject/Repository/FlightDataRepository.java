package com.ivl.miniproject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ivl.miniproject.Model.FlightData;

public interface FlightDataRepository extends JpaRepository<FlightData, String> {

}
