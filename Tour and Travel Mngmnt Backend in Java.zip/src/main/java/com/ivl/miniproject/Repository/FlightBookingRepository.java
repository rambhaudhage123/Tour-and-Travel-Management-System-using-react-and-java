package com.ivl.miniproject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ivl.miniproject.Model.FlightBookingData;

public interface FlightBookingRepository extends JpaRepository<FlightBookingData, Long>{

}
