package com.ivl.miniproject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ivl.miniproject.Model.HotelData;

public interface HotelDataRepository extends JpaRepository<HotelData, Long> {

}
