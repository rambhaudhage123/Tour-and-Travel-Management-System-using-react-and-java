package com.ivl.miniproject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ivl.miniproject.Model.HotelRegistrationData;

public interface HotelRegistrationRepository extends JpaRepository<HotelRegistrationData, Long> {

}
