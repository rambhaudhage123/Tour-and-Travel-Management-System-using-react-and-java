package com.ivl.miniproject.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="HotelRegistrationData")
@Data
public class HotelRegistrationData {
	@Id
	long invoiceNumber;
    String personName;
    String personNameOnCard;
    String personEmail;
    String personPhoneNo;
    String cardDetail;
    int hotelID;
    String hotelNameToDatabase;
    String hotelphoneNoToDatabase;
    String checkinDateToDatabase;
    String checkOutDateToDatabase;
    String noOfGuest;
    String noOfRoom;
    int finalPrice;
	public long getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getPersonNameOnCard() {
		return personNameOnCard;
	}
	public void setPersonNameOnCard(String personNameOnCard) {
		this.personNameOnCard = personNameOnCard;
	}
	public String getPersonEmail() {
		return personEmail;
	}
	public void setPersonEmail(String personEmail) {
		this.personEmail = personEmail;
	}
	public String getPersonPhoneNo() {
		return personPhoneNo;
	}
	public void setPersonPhoneNo(String personPhoneNo) {
		this.personPhoneNo = personPhoneNo;
	}
	public String getCardDetail() {
		return cardDetail;
	}
	public void setCardDetail(String cardDetail) {
		this.cardDetail = cardDetail;
	}
	public int getHotelID() {
		return hotelID;
	}
	public void setHotelID(int hotelID) {
		this.hotelID = hotelID;
	}
	public String getHotelNameToDatabase() {
		return hotelNameToDatabase;
	}
	public void setHotelNameToDatabase(String hotelNameToDatabase) {
		this.hotelNameToDatabase = hotelNameToDatabase;
	}
	public String getHotelphoneNoToDatabase() {
		return hotelphoneNoToDatabase;
	}
	public void setHotelphoneNoToDatabase(String hotelphoneNoToDatabase) {
		this.hotelphoneNoToDatabase = hotelphoneNoToDatabase;
	}
	public String getCheckinDateToDatabase() {
		return checkinDateToDatabase;
	}
	public void setCheckinDateToDatabase(String checkinDateToDatabase) {
		this.checkinDateToDatabase = checkinDateToDatabase;
	}
	public String getCheckOutDateToDatabase() {
		return checkOutDateToDatabase;
	}
	public void setCheckOutDateToDatabase(String checkOutDateToDatabase) {
		this.checkOutDateToDatabase = checkOutDateToDatabase;
	}
	public String getNoOfGuest() {
		return noOfGuest;
	}
	public void setNoOfGuest(String noOfGuest) {
		this.noOfGuest = noOfGuest;
	}
	public String getNoOfRoom() {
		return noOfRoom;
	}
	public void setNoOfRoom(String noOfRoom) {
		this.noOfRoom = noOfRoom;
	}
	public int getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(int finalPrice) {
		this.finalPrice = finalPrice;
	}
	public HotelRegistrationData(long invoiceNumber, String personName, String personNameOnCard, String personEmail,
			String personPhoneNo, String cardDetail, int hotelID, String hotelNameToDatabase,
			String hotelphoneNoToDatabase, String checkinDateToDatabase, String checkOutDateToDatabase,
			String noOfGuest, String noOfRoom, int finalPrice) {
		super();
		this.invoiceNumber = invoiceNumber;
		this.personName = personName;
		this.personNameOnCard = personNameOnCard;
		this.personEmail = personEmail;
		this.personPhoneNo = personPhoneNo;
		this.cardDetail = cardDetail;
		this.hotelID = hotelID;
		this.hotelNameToDatabase = hotelNameToDatabase;
		this.hotelphoneNoToDatabase = hotelphoneNoToDatabase;
		this.checkinDateToDatabase = checkinDateToDatabase;
		this.checkOutDateToDatabase = checkOutDateToDatabase;
		this.noOfGuest = noOfGuest;
		this.noOfRoom = noOfRoom;
		this.finalPrice = finalPrice;
	}
	public HotelRegistrationData() {
		super();
	}
    
    
}
