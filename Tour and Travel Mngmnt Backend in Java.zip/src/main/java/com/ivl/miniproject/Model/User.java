package com.ivl.miniproject.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Users_Data")
@Data
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Long user_id;
	public String fullName;
	public String username;
	public String password;
	public String address;
	public Long phoneNo;
	public boolean status;
	public String role;

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Long getUser_id() {
		return user_id;
	}

	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public User() {
		super();
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public User(String fullName, String username, String password, String address, Long phoneNo, boolean status,
			String role) {
		super();
		this.fullName = fullName;
		this.username = username;
		this.password = password;
		this.address = address;
		this.phoneNo = phoneNo;
		this.status = status;
		this.role = role;
	}

}
