package com.ivl.miniproject.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="FlightBookingData")
@Data
public class FlightBookingData {
	@Id
	long invoiceNumber;
    String personName;
    String personNameOnCard;
    String personEmail;
    String personPhoneNo;
    String cardDetail;
    String flightID;
    String flightImage;
    String fromCity;
    String toCity;
    String departDate;
    String arrivalDate;
    int noOfPassenger;
    String typeOfClass;
    int ticketPrice;
	public long getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getPersonNameOnCard() {
		return personNameOnCard;
	}
	public void setPersonNameOnCard(String personNameOnCard) {
		this.personNameOnCard = personNameOnCard;
	}
	public String getPersonEmail() {
		return personEmail;
	}
	public void setPersonEmail(String personEmail) {
		this.personEmail = personEmail;
	}
	public String getPersonPhoneNo() {
		return personPhoneNo;
	}
	public void setPersonPhoneNo(String personPhoneNo) {
		this.personPhoneNo = personPhoneNo;
	}
	public String getCardDetail() {
		return cardDetail;
	}
	public void setCardDetail(String cardDetail) {
		this.cardDetail = cardDetail;
	}
	public String getFlightID() {
		return flightID;
	}
	public void setFlightID(String flightID) {
		this.flightID = flightID;
	}
	public String getFlightImage() {
		return flightImage;
	}
	public void setFlightImage(String flightImage) {
		this.flightImage = flightImage;
	}
	public String getFromCity() {
		return fromCity;
	}
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}
	public String getToCity() {
		return toCity;
	}
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}
	public String getDepartDate() {
		return departDate;
	}
	public void setDepartDate(String departDate) {
		this.departDate = departDate;
	}
	public String getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public int getNoOfPassenger() {
		return noOfPassenger;
	}
	public void setNoOfPassenger(int noOfPassenger) {
		this.noOfPassenger = noOfPassenger;
	}
	public String getTypeOfClass() {
		return typeOfClass;
	}
	public void setTypeOfClass(String typeOfClass) {
		this.typeOfClass = typeOfClass;
	}
	public int getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(int ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public FlightBookingData(long invoiceNumber, String personName, String personNameOnCard, String personEmail,
			String personPhoneNo, String cardDetail, String flightID, String flightImage, String fromCity,
			String toCity, String departDate, String arrivalDate, int noOfPassenger, String typeOfClass,
			int ticketPrice) {
		super();
		this.invoiceNumber = invoiceNumber;
		this.personName = personName;
		this.personNameOnCard = personNameOnCard;
		this.personEmail = personEmail;
		this.personPhoneNo = personPhoneNo;
		this.cardDetail = cardDetail;
		this.flightID = flightID;
		this.flightImage = flightImage;
		this.fromCity = fromCity;
		this.toCity = toCity;
		this.departDate = departDate;
		this.arrivalDate = arrivalDate;
		this.noOfPassenger = noOfPassenger;
		this.typeOfClass = typeOfClass;
		this.ticketPrice = ticketPrice;
	}
	public FlightBookingData() {
		super();
	}
    
	
}
