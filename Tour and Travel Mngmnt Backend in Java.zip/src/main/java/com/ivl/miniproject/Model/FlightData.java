package com.ivl.miniproject.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="IVL_Travels_FlightData")
@Data
public class FlightData {
	
	@Id
	public String code;
	public String arrival;
	public String arrivalTime;
	public String depart;
	public 	String departTime;
	public String fromCity;
	public int price;
	public String toCity;
	public String flightImg;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getDepart() {
		return depart;
	}
	public void setDepart(String depart) {
		this.depart = depart;
	}
	public String getDepartTime() {
		return departTime;
	}
	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}
	public String getFromCity() {
		return fromCity;
	}
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getToCity() {
		return toCity;
	}
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}
	public String getFlightImg() {
		return flightImg;
	}
	public void setFlightImg(String flightImg) {
		this.flightImg = flightImg;
	}
	public FlightData(String code, String arrival, String arrivalTime, String depart, String departTime,
			String fromCity, int price, String toCity, String flightImg) {
		super();
		this.code = code;
		this.arrival = arrival;
		this.arrivalTime = arrivalTime;
		this.depart = depart;
		this.departTime = departTime;
		this.fromCity = fromCity;
		this.price = price;
		this.toCity = toCity;
		this.flightImg = flightImg;
	}
	public FlightData() {
		super();
	}
	
	
	
}
