package com.ivl.miniproject.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ivl.miniproject.Exception.ResourceNotFoundException;
import com.ivl.miniproject.Model.FlightData;
import com.ivl.miniproject.Repository.FlightDataRepository;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequestMapping("/flightData")
public class FlightDataController {
	
	@Autowired
	FlightDataRepository flightDataRepository;
	
	@GetMapping("/getallflights")
	public List<FlightData> getAllFlights() {
		System.out.println(flightDataRepository.findAll());
		return flightDataRepository.findAll();
		
	}
	
	@PostMapping("/addflight")
	public FlightData createUser(@RequestBody FlightData flight) {
		return flightDataRepository.save(flight);
	}
	
	@PutMapping("/updateflight/{code}")
	public ResponseEntity<FlightData> updateFlight(@PathVariable String code, @RequestBody FlightData flight) throws ResourceNotFoundException {
		FlightData flightNew = flightDataRepository.findById(code)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + code));

		flightNew.setCode(flight.getCode());
		flightNew.setArrival(flight.getArrival());
		flightNew.setArrivalTime(flight.getArrivalTime());
		flightNew.setDepart(flight.getDepart());
		flightNew.setDepartTime(flight.getDepartTime());
		flightNew.setFromCity(flight.getFromCity());
		flightNew.setPrice(flight.getPrice());
		flightNew.setToCity(flight.getToCity());
		flightNew.setFlightImg(flight.getFlightImg());
		FlightData updatedFlight =flightDataRepository.save(flightNew);
		return ResponseEntity.ok(updatedFlight);
		
	}
	// delete user rest api
	@DeleteMapping("/deleteflight/{code}")
	public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable String code) {
		FlightData flight = flightDataRepository.findById(code)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + code));

		flightDataRepository.delete(flight);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	

}
