package com.ivl.miniproject.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ivl.miniproject.Exception.ResourceNotFoundException;
import com.ivl.miniproject.Model.HotelData;
import com.ivl.miniproject.Repository.HotelDataRepository;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequestMapping("/hotelData")
public class HotelDataController {
	@Autowired
	HotelDataRepository hotelDatarepo;

	@GetMapping("/getallhotels/{city}")
	public List<HotelData> getAllHotels(@PathVariable String city) {
		ArrayList<HotelData> selectedHotel = new ArrayList<HotelData>();
		List<HotelData> hotel = hotelDatarepo.findAll();
		for (HotelData hotelData : hotel) {
			if (hotelData.getCity().equalsIgnoreCase(city)) {
				selectedHotel.add(hotelData);
			}
		}
		return selectedHotel;
	}

	@GetMapping("/gethotel/{id}")
	public Optional<HotelData> getHotel(@PathVariable long id) {
		Optional<HotelData> hotel = hotelDatarepo.findById(id);
		return hotel;
	}

	@GetMapping("/getallhotels")
	public List<HotelData> getAllUser() {
		return hotelDatarepo.findAll();
	}

	// create user rest api
	@PostMapping("/addhotel")
	public HotelData createUser(@RequestBody HotelData hotel) {
		return hotelDatarepo.save(hotel);
	}

	@PutMapping("/updatehotel/{id}")
	public ResponseEntity<HotelData> updateUser(@PathVariable Long id, @RequestBody HotelData updateHotel) {
		HotelData hotel = hotelDatarepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		hotel.setHotel_id(id);
		hotel.setHotelName(updateHotel.getHotelName());
		hotel.setPhoneNo(updateHotel.getPhoneNo());
		hotel.setLocation(updateHotel.getLocation());
		hotel.setCity(updateHotel.getCity());
		hotel.setRating(updateHotel.getRating());
		hotel.setNoOfRooms(updateHotel.getNoOfRooms());
		hotel.setRoom_id(updateHotel.getRoom_id());
		HotelData updatedHotel = hotelDatarepo.save(hotel);
		return ResponseEntity.ok(updatedHotel);
	}

	// delete user rest api
	@DeleteMapping("/deletehotel/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable Long id) {
		HotelData hotel = hotelDatarepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

		hotelDatarepo.delete(hotel);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}
