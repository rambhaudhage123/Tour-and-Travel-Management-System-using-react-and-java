package com.ivl.miniproject.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ivl.miniproject.Model.FlightBookingData;
import com.ivl.miniproject.Repository.FlightBookingRepository;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequestMapping("/flightBooking")
public class FlightBookingController {
	@Autowired
	FlightBookingRepository flightBookingRepository;
	
	@PostMapping("/flightbookingData")
	public FlightBookingData addRegistrationData(@RequestBody FlightBookingData registration) {
		System.out.println(registration);
		return flightBookingRepository.save(registration);
	}
	@GetMapping("/getflightbooking/{email}")
	public List<FlightBookingData> getAllFlights(@PathVariable String email) {
		ArrayList<FlightBookingData> selectedFlight = new ArrayList<FlightBookingData>(); 
		List<FlightBookingData> Flight = flightBookingRepository.findAll();
		for (FlightBookingData flightData : Flight) {
			if(flightData.getPersonEmail().equalsIgnoreCase(email)) {
				selectedFlight.add(flightData);
			}
		}
		return selectedFlight;
	}
	@DeleteMapping("/deleteflightbooking/{invoiceNumber}")
	public void deleteFlightBooking(@PathVariable long invoiceNumber) {
		FlightBookingData data = flightBookingRepository.findById(invoiceNumber).get();
		flightBookingRepository.delete(data);
	}
}
