package com.ivl.miniproject.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ivl.miniproject.Exception.ResourceNotFoundException;
import com.ivl.miniproject.Model.User;
import com.ivl.miniproject.Repository.UserRepository;

@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/register")
	public User addBook(@RequestBody User newuser) {
		System.out.println(newuser);
		return userRepository.save(newuser);
	}

	// get all users
	@GetMapping("/getallusers")
	public List<User> getAllUser() {
		return userRepository.findAll();
	}

	// get all users for manage user
	@GetMapping("/getusers")
	public List<User> getUsers() {
		List<User> allUser = userRepository.findAll();
		List<User> user = new ArrayList<User>();
		for (User newuser : allUser) {
			if (newuser.role.equalsIgnoreCase("USER")) {
				user.add(newuser);
			}
		}
		System.out.println(user);
		return user;
	}

	// get all admin for manage admin
	@GetMapping("/getadmins")
	public List<User> getAdmins() {
		List<User> allUser = userRepository.findAll();
		List<User> admins = new ArrayList<User>();
		for (User newuser : allUser) {
			if (newuser.role.equalsIgnoreCase("ADMIN"))
				admins.add(newuser);
		}
		return admins;
	}

	// create user rest api
	@PostMapping("/adduser")
	public User createUser(@RequestBody User employee) {
		return userRepository.save(employee);
	}

	// get user by id rest api
	@GetMapping("/getuserbyid/{id}")
	public ResponseEntity<User> getUserById(@PathVariable Long id) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		return ResponseEntity.ok(user);
	}

	@GetMapping("/userstatus/{id}/{status}")
	public ResponseEntity<User> userStatus(@PathVariable Long id, @PathVariable int status) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		System.out.println("status " + status);
		if (status == 1) {
			user.status = true;
		} else
			user.status = false;
		User updatedUser = userRepository.save(user);
		return ResponseEntity.ok(updatedUser);
	}
	// update user rest api

	@PutMapping("/updateuser/{id}")
	public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User userDetails) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		user.setUser_id(id);
		user.setFullName(userDetails.getFullName());
		user.setUsername(userDetails.getUsername());
		user.setPassword(userDetails.getPassword());
		user.setAddress(userDetails.getAddress());
		user.setPhoneNo(userDetails.getPhoneNo());
		user.setStatus(userDetails.isStatus());
		user.setRole(userDetails.getRole());
		User updatedUser = userRepository.save(user);
		return ResponseEntity.ok(updatedUser);
	}

	// delete user rest api
	@DeleteMapping("/deleteuser/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable Long id) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

		userRepository.delete(user);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

}
