import Router from './Components/Router/Router';
import Footer from './Components/Navbar-Footer/Footer';
import background from "./background.jpg";

function App() {
  return (
    <div style={{ backgroundImage: `url(${background})` }}>
      <Router />
      <Footer />
    </div>
  );
}

export default App;
