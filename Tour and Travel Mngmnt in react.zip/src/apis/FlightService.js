import axios from 'axios'

const URL_FLIGHT = 'http://localhost:8081/flightData';
const URL_BOOKING = 'http://localhost:8081/flightBooking';
class FlightService {
    //Flight
    getAllFlights() {
        return axios.get(URL_FLIGHT + `/getallflights`);
    }
    addFlight(flight){
        return axios.post(URL_FLIGHT + `/addflight`,flight);
    }
    updateFlight(code,flight){
        return axios.put(URL_FLIGHT + `/updateflight/`+code,flight);
    }
    deleteFlight(code){
        return axios.delete(URL_FLIGHT + `/deleteflight/`+code);
    }
    sendBookingData(objectToSend) {
        return axios.post(URL_BOOKING + `/flightbookingData`, objectToSend)
    }
    //Dashboard
    getFlightBooking(email) {
        console.log(email)
        return axios.get(URL_BOOKING + `/getflightbooking/` + email);
    }
    deleteFlightBooking(invoiceNumber) {
        return axios.delete(URL_BOOKING + `/deleteflightbooking/` + invoiceNumber)
    }
}
export default new FlightService();