import axios from 'axios'

const URL_USER = 'http://localhost:8081/users';
const URL_HOTEL = 'http://localhost:8081/hotelData';
const URL_REGISTRATION = 'http://localhost:8081/hotelBooking';

class UserService {
    //Users
    addUser(userDetails) {
        console.log(userDetails)
        return axios.post(URL_USER + `/register`, userDetails)
    }
    getAllUsers() {
        return axios.get(URL_USER + `/getallusers`);
    }
    getUsers() {
        return axios.get(URL_USER + `/getusers`);
    }
    getAdmins() {
        return axios.get(URL_USER + `/getadmins`);
    }
    updateUser(id, user) {
        return axios.put(URL_USER + `/updateuser/` + id, user);
    }
    userStatusUpdate(id, status) {
        return axios.get(URL_USER + `/userstatus/` + id + `/` + status);
    }
    deleteUser(id) {
        return axios.delete(URL_USER + `/deleteuser/` + id);
    }

    //Hotels
    getHotel(city) {
        console.log(city)
        return axios.get(URL_HOTEL + `/getallhotels/` + city);
    }
    getCurrentHotel(id) {
        console.log(id)
        return axios.get(URL_HOTEL + `/gethotel/` + id);
    }
    sendData(objectToSend) {
        console.log(objectToSend)
        return axios.post(URL_REGISTRATION + `/bookingData`, objectToSend)
    }

    //Dashboard
    getHotelReservation(email) {
        console.log(email)
        return axios.get(URL_REGISTRATION + `/gethotelreservation/` + email);
    }
    deleteHotelReservation(invoiceNumber) {
        return axios.delete(URL_REGISTRATION + `/deletehotelreservation/` + invoiceNumber)
    }

    //Superadmin
    getAllHotels() {
        return axios.get(URL_HOTEL + `/getallhotels`);
    }
    addHotel(Hotel) {
        return axios.post(URL_HOTEL + `/addhotel`, Hotel)
    }
    updateHotel(id, Hotel) {
        return axios.put(URL_HOTEL + `/updatehotel/` + id, Hotel)
    }
    deleteHotel(id) {
        return axios.delete(URL_HOTEL + `/deletehotel/` + id);
    }
}
export default new UserService();