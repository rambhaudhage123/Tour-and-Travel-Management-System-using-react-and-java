import React, { useEffect, useState } from 'react'
import NavBar from '../Navbar-Footer/NavBar'
import { useLocation } from 'react-router-dom'
import UserService from '../../apis/UserService'
import FlightService from '../../apis/FlightService'

const Dashboard = () => {
    const [hotelReservations, setHotelReservations] = useState([]);
    const [flightBooking, setFlightBooking] = useState([]);
    const location = useLocation();
    const dataReceived = location.state.Data.dataToDashboard;
    console.log(dataReceived)

    useEffect(() => {
        const getHotels = async () => {
            const data = await UserService.getHotelReservation(dataReceived.username).then((response) => {
                setHotelReservations(response.data)
            });
            console.log(data)
        }
        getHotels()
    }, [dataReceived.username])
    console.log(hotelReservations)

    useEffect(() => {
        const getFlights = async () => {
            const data = await FlightService.getFlightBooking(dataReceived.username).then((response) => {
                setFlightBooking(response.data)
            });
            console.log(data)
        }
        getFlights()
    }, [dataReceived.username])
    console.log(flightBooking)

    const deleteHotelBooking = (invoiceNumber) => {
        UserService.deleteHotelReservation(invoiceNumber).then((response) => {
            console.log(response)
        })
    }
    const deleteFlightBooking = (invoiceNumber) => {
        FlightService.deleteFlightBooking(invoiceNumber).then((response) => {
            console.log(response)
        })
    }
    return (
        <>

            <NavBar />
            <div className='w-25 text-center p-1 m-2  border rounded'>
                <h5>User Dashboard</h5>
            </div>
            <div className='m-3'>
                <h6>Name:&emsp;&emsp;&emsp; {dataReceived.fullName}</h6>
                <h6>Phone no:&emsp; {dataReceived.phoneNo}</h6>
                <h6>Email:&emsp;&emsp;&emsp; {dataReceived.username}</h6>
            </div>

            <div className="mt-3 border p-2">
                <h3 className="text-center">Hotel Bookings</h3>
                <div className="mt-3 p-4">
                    <table className="table table-striped">
                        <thead className="table-dark">
                            <tr className="text-center">
                                <th>Invoice no.</th>
                                <th>Hotel name</th>
                                <th>No of rooms</th>
                                <th>No of guests</th>
                                <th>Check in Date</th>
                                <th>Check out Date</th>
                                <th>Booking amount</th>
                                <th>Cancellation</th>
                            </tr>
                        </thead>
                        <tbody className="tbody">
                            {
                                hotelReservations.map(reservation => {
                                    return (
                                        <tr className="text-center" key={reservation.invoiceNumber}>
                                            <td>{reservation.invoiceNumber}</td>
                                            <td>{reservation.hotelNameToDatabase}</td>
                                            <td>{reservation.noOfRoom}</td>
                                            <td>{reservation.noOfGuest}</td>
                                            <td>{reservation.checkinDateToDatabase}</td>
                                            <td>{reservation.checkOutDateToDatabase}</td>
                                            <td>{reservation.finalPrice}</td>
                                            <td><button onClick={() => deleteHotelBooking(reservation.invoiceNumber)} type="button" className="btn btn-danger">Cancel Reservation</button></td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody >
                    </table >
                </div >
            </div>

            <div className="mt-3 border p-2">
                <h3 className="text-center">Flight Bookings</h3>
                <div className="mt-3 p-4">
                    <table className="table table-striped">
                        <thead className="table-dark">
                            <tr className="text-center">
                                <th>Airline</th>
                                <th>Invoice no.</th>
                                <th>From City</th>
                                <th>To City</th>
                                <th>Departure date</th>
                                <th>Passenger</th>
                                <th>Type of class</th>
                                <th>Ticket Price</th>
                                <th>Cancellation</th>
                            </tr>
                        </thead>
                        <tbody className="tbody">
                            {
                                flightBooking.map(reservation => {
                                    return (
                                        <tr className="text-center" key={reservation.invoiceNumber}>
                                            <td>
                                                <div style={{ height: '80px', width: '110px' }}>
                                                    <img
                                                        src={reservation.flightImage}
                                                        alt="flight_img"
                                                        style={{ height: '100%', width: '100%' }}
                                                    />
                                                </div>
                                            </td>
                                            <td>{reservation.invoiceNumber}</td>
                                            <td>{reservation.fromCity}</td>
                                            <td>{reservation.toCity}</td>
                                            <td>{reservation.departDate}</td>
                                            <td>{reservation.noOfPassenger}</td>
                                            <td>{reservation.typeOfClass.toUpperCase()}</td>
                                            <td>{reservation.ticketPrice}</td>
                                            <td><button onClick={() => deleteFlightBooking(reservation.invoiceNumber)} type="button" className="btn btn-danger">Cancel Reservation</button></td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody >
                    </table >
                </div >
            </div>
        </>
    )
}

export default Dashboard