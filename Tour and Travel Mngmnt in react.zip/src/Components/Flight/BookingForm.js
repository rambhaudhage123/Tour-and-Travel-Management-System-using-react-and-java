import React from "react";
import { useState } from 'react'
import { useLocation, useNavigate } from "react-router-dom";
import NavBar from "../Navbar-Footer/NavBar";
import PhoneInput from 'react-phone-input-2'



const BookingForm = () => {
  const [firstName, setFirstName] = useState()
  const [lastName, setLastName] = useState()
  const [mobNo, setMobNo] = useState()
  const [email, setEmail] = useState()
  const [classType, setClassType] = useState()

  const location = useLocation();
  const navigate = useNavigate()
  const flightDetails = location.state.data;
  const passenger = location.state.passengerCount;
  const handleOnSubmit = (e) => {
    e.preventDefault()
    navigate('/flightPaymentPage', { state: { firstName, lastName, mobNo, email, classType, flightDetails, passenger } })
  }

  return (
    <>
      <NavBar />
      <div className="BookingForm">
        <div className="text-center d-flex justify-content-center ">
          <div className='border border-primary rounded w-30 mt-3 bg-light text-dark'>
            <form onSubmit={handleOnSubmit}>
              <div className="d-flex text-center">
                <div className="form-group m-2 d-inline-block mt-2">
                  <label for="fname"><span>First name </span>
                    <input onChange={(e) => setFirstName(e.target.value)} className="form-control" id="fname" type="text" required />
                  </label>
                </div>
                <div className="form-group m-2 d-inline-block mt-2">
                  <label for="lname"><span>Last name </span>
                    <input onChange={(e) => setLastName(e.target.value)} className="form-control" id="lname" type="text" required />
                  </label>
                </div>
              </div>
              <div className="form-group m-2 ">
                <label htmlFor="lname">
                  <PhoneInput
                    country={'in'}
                    value={mobNo}
                    onChange={phone => setMobNo(phone)}
                    required
                  />
                </label>
              </div>
              <div className="form-group m-2">
                <label for="lname"><span>Email </span>
                  <input onChange={(e) => setEmail(e.target.value)} className="form-control" id="lname" type="email" required />
                </label>
              </div>
              <div className="form-group">
                <label for="typeofclass"><span>Type of Class</span>
                  <select onChange={(e) => setClassType(e.target.value)} className="form-select text-center" required>
                    <option selected value="">Class</option>
                    <option value="economy">Economy</option>
                    <option value="first">First Class</option>
                    <option value="business">Business</option>
                  </select>
                </label>
              </div>

              <div className="form-group d-inline-block m-3">
                <label for="checkin"><span>Departure Date</span>
                  <input value={flightDetails.depart} className="form-control text-center" disabled />
                </label>
              </div>
              <div className="form-group d-inline-block ">
                <label for="checkout"><span>Departure time</span>
                  <input value={flightDetails.departTime} className="form-control text-center" disabled />
                </label>
              </div>
              <div className="form-group">
                <label for="room"><span>No of passenger</span>
                  <input value={passenger} className="form-control text-center" disabled />
                </label>
              </div>

              <div className="d-flex text-center">
                <div className="form-group m-2 d-inline-block mt-2">
                  <label for="room"><span>From City</span>
                    <input value={flightDetails.fromCity} className="form-control text-center" disabled />
                  </label>
                </div>
                <div className="form-group m-2 d-inline-block mt-2">
                  <label for="room"><span>To City</span>
                    <input value={flightDetails.toCity} className="form-control text-center" disabled />
                  </label>
                </div>
              </div>
              <button type='submit' className="btn btn-primary m-3 w-75 fw-bolder fs-6 mb-5">Book Now!</button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookingForm;
