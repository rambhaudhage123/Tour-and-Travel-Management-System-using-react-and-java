import React from 'react'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import FlightService from '../../apis/FlightService'

const FlightTicket = () => {
    const location = useLocation();
    const navigate = useNavigate();
    console.log(location.state)
    const finalData = location.state;

    const current = new Date();
    const date = `${current.getDate()}/${current.getMonth() + 1}/${current.getFullYear()}`;

    if (finalData.userDetails.classType === "first") {
        var Price = (finalData.userDetails.flightDetails.price + 1000);
    } else if (finalData.userDetails.classType === "bussiness") {
        // eslint-disable-next-line no-redeclare
        var Price = (finalData.userDetails.flightDetails.price + 1500);
    } else {
        // eslint-disable-next-line no-redeclare
        var Price = (finalData.userDetails.flightDetails.price);
    }

    //List of data to send in database
    const invoiceNumber = finalData.invoiceNo;
    const personName = finalData.userDetails.firstName + finalData.userDetails.lastName;
    const personNameOnCard = finalData.personName;
    const personEmail = finalData.userDetails.email;
    const personPhoneNo = finalData.userDetails.mobNo;
    const cardDetail = finalData.cardNo;
    const flightID = finalData.userDetails.flightDetails.code;
    const flightImage = finalData.userDetails.flightDetails.flightImg;
    const departDate = finalData.userDetails.flightDetails.depart;
    const arrivalDate = finalData.userDetails.flightDetails.arrival;
    const fromCity = finalData.userDetails.flightDetails.fromCity;
    const toCity = finalData.userDetails.flightDetails.toCity;
    const noOfPassenger = finalData.userDetails.passenger;
    const typeOfClass = finalData.userDetails.classType;
    const ticketPrice = finalData.finalPrice;
    const objectToSend = {
        invoiceNumber,
        personName,
        personNameOnCard,
        personEmail,
        personPhoneNo,
        cardDetail,
        flightID,
        flightImage,
        fromCity,
        toCity,
        departDate,
        arrivalDate,
        noOfPassenger,
        typeOfClass,
        ticketPrice
    };
    console.log(objectToSend)

    useEffect(() => {
        const sendBookingData = async () => {
            const data = await FlightService.sendBookingData(objectToSend).then();
            console.log(data)
        }
        sendBookingData()
        
    }, [])

    return (
        <>
            <div className="container mt-5">
                <div className="row gutters">
                    <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div className="card">
                            <div className="card-body p-0">
                                <div className="invoice-container">
                                    <div className="row gutters">
                                        <div className="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                            <div className="invoice-details">
                                                <address>
                                                    {finalData.personName}<br />
                                                    <p className="m-0 text-muted">
                                                        {finalData.userDetails.email}<br />
                                                        {finalData.cardNo}
                                                    </p>
                                                </address>
                                            </div>
                                        </div>
                                        <div className="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                                            <div className="invoice-details">
                                                <div className="invoice-num">
                                                    <div>Invoice - #{finalData.invoiceNo}</div>
                                                    <div>{date}</div><br />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="invoice-body">
                                    <div className="row gutters">
                                        <div className="col-lg-12 col-md-12 col-sm-12">
                                            <div className="table-responsive">
                                                <table className="table custom-table m-0">
                                                    <thead>
                                                        <tr className="text-center">
                                                            <th>Airline</th>
                                                            <th>Depature Date</th>
                                                            <th>Depature Time</th>
                                                            <th>Arrival Date</th>
                                                            <th>Arrival Time</th>
                                                            <th>No. Passenger</th>
                                                            <th>Class</th>
                                                            <th>Sub Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr className="text-center">
                                                            <td>
                                                                <div style={{ height: '80px', width: '110px' }}>
                                                                    <img
                                                                        src={finalData.userDetails.flightDetails.flightImg}
                                                                        alt="flight_img"
                                                                        style={{ height: '100%', width: '100%' }}
                                                                    />
                                                                </div>
                                                            </td>
                                                            <td>{finalData.userDetails.flightDetails.depart}</td>
                                                            <td>{finalData.userDetails.flightDetails.departTime}</td>
                                                            <td>{finalData.userDetails.flightDetails.arrival}</td>
                                                            <td>{finalData.userDetails.flightDetails.arrivalTime}</td>
                                                            <td>{finalData.userDetails.passenger}</td>
                                                            <td>{finalData.userDetails.classType.toUpperCase()}</td>
                                                            <td>{finalData.finalPrice} Rs.</td>
                                                        </tr>

                                                        <tr>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>
                                                                <p>
                                                                    Subtotal<br />
                                                                    Tax<br />
                                                                </p>
                                                                <h5 className="text-success"><strong>Grand Total</strong></h5>
                                                            </td>
                                                            <td>
                                                                <p>
                                                                    {Price} Rs.<br />
                                                                    {finalData.finalPrice - Price} Rs.<br />
                                                                </p>
                                                                <h5 className="text-success"><strong>{finalData.finalPrice} Rs.</strong></h5>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="text-center">
                <button className="btn btn-secondary mt-3" onClick={() => { window.print(); return false; }}>Print Ticket</button>
                <button className="btn btn-primary mt-3" onClick={() => navigate(`/home`)}>Home</button>
            </div>
        </>
    )
}

export default FlightTicket