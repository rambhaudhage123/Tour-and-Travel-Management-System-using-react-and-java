
import React from "react";
import { Link } from 'react-router-dom'
import NavBar from "../Navbar-Footer/NavBar";
const Showcase = () => {

  return (
    <>
      <NavBar />
      <section className='showcase'>

        <div className='showcase-overlay'>

          <h1>IVL Travels</h1>
          <p>
            Get to tour the world in style. Select a destination, book your
            flight, and off you go!
          </p>
          <Link className='linktosearch' to='/search'>
            PLAN A JOURNEY
          </Link>
        </div>
      </section>
    </>
  )
}

export default Showcase
