import React from 'react'
import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import NavBar from '../Navbar-Footer/NavBar'

const FlightPaymentPage = () => {
    const [personName, setPersonName] = useState()
    const [cardNo, setCardNo] = useState()

    const navigate = useNavigate()
    const location = useLocation();
    const userDetails = location.state;

    if (userDetails.classType === "first") {
        var finalPrice = (userDetails.flightDetails.price + 1000) + ((userDetails.flightDetails.price + 1000) * 0.12);
    } else if (userDetails.classType === "bussiness") {
        // eslint-disable-next-line no-redeclare
        var finalPrice = (userDetails.flightDetails.price + 1500) + ((userDetails.flightDetails.price + 1500) * 0.15);
    } else {
        // eslint-disable-next-line no-redeclare
        var finalPrice = (userDetails.flightDetails.price) + (userDetails.flightDetails.price * 0.05);
    }

    const invoiceNo = Math.floor(Math.random() * 100000);

    const handleOnSubmit = (e) => {
        e.preventDefault()
        navigate('/flightticket', { state: { invoiceNo, personName, cardNo, userDetails, finalPrice } })
    }



    return (
        <>
            <NavBar />
            <div className="container p-0 mt-3 w-50">
                <div className="card px-4">
                    <form onSubmit={handleOnSubmit}>
                        <div className='d-flex text-center'>
                            <p className="h8 py-3 fw-bolder fs-3">Payment Details</p>
                            <div className="icons m-3">
                                <img src="https://img.icons8.com/color/48/000000/visa.png" alt='' />
                                <img src="https://img.icons8.com/color/48/000000/mastercard-logo.png" alt='' />
                                <img src="https://img.icons8.com/color/48/000000/maestro.png" alt='' />
                            </div>
                        </div>

                        <div className="row gx-3">
                            <div className="col-12">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">Person Name</p>
                                    <input onChange={(e) => setPersonName(e.target.value)} className="form-control mb-3" type="text" placeholder="Name" required />
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">Card Number</p>
                                    <input onChange={(e) => setCardNo(e.target.value)} className="form-control mb-3" type="number" placeholder="1234 5678 4356 5469" autocomplete="off" min='12' required />
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">Expiry</p>
                                    <input className="form-control mb-3" type="text" placeholder="MM/YYYY" required />
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">CVV/CVC</p>
                                    <input className="form-control mb-3 pt-2 " type="password" placeholder="***" min="3" max="3" required />
                                </div>
                            </div>
                            <div className="col-12 text-center">
                                <button type='submit' className="btn btn-primary mb-3 text-center w-25"><span className="fw-bold fs-6">Pay {finalPrice}</span>Rs.</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}

export default FlightPaymentPage