import React from 'react'
import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import NavBar from '../Navbar-Footer/NavBar'

const PaymentPage = () => {
    const [personName, setPersonName] = useState()
    const [cardNo, setCardNo] = useState()

    const navigate = useNavigate()
    const location = useLocation();
    const Details = location.state;

    const handleOnSubmit = (e) => {
        e.preventDefault()
        navigate('/ticket', { state: { Details, personName, cardNo, duration, invoiceNo } })
    }
    const invoiceNo = Math.floor(Math.random() * 10000000000);
    var date1 = new Date(Details.checkinDate);
    var date2 = new Date(Details.checkoutDate);
    const diffInMs = Math.abs(date2 - date1);
    const duration = diffInMs / (1000 * 60 * 60 * 24);
    console.log(Details.roomType)
    if (Details.roomType === "Ac") {
        var final = Details.hotelDetails.room_id + 1000;
    } else if (Details.roomType === "dulex") {
        // eslint-disable-next-line no-redeclare
        var final = Details.hotelDetails.room_id + 1500;
    } else {
        // eslint-disable-next-line no-redeclare
        var final = Details.hotelDetails.room_id;
    }


    return (
        <>
            <NavBar />
            <div className="container p-0 mt-3 w-50">
                <div className="card px-4">
                    <form onSubmit={handleOnSubmit}>
                        <div className='d-flex text-center'>
                            <p className="h8 py-3 fw-bolder fs-3">Payment Details</p>
                            <div className="icons m-3">
                                <img src="https://img.icons8.com/color/48/000000/visa.png" alt='' />
                                <img src="https://img.icons8.com/color/48/000000/mastercard-logo.png" alt='' />
                                <img src="https://img.icons8.com/color/48/000000/maestro.png" alt='' />
                            </div>
                        </div>

                        <div className="row gx-3">
                            <div className="col-12">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">Person Name</p>
                                    <input onChange={(e) => setPersonName(e.target.value)} className="form-control mb-3" type="text" placeholder="Name" required />
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">Card Number</p>
                                    <input onChange={(e) => setCardNo(e.target.value)} className="form-control mb-3" type="number" placeholder="1234 5678 4356 5469" autocomplete="off" min='12' required />
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">Expiry</p>
                                    <input className="form-control mb-3" type="text" placeholder="MM/YYYY" required />
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="d-flex flex-column">
                                    <p className="text mb-1">CVV/CVC</p>
                                    <input className="form-control mb-3 pt-2 " type="password" placeholder="***" min="3" max="3" required />
                                </div>
                            </div>
                            <div className="col-12 text-center">
                                <button type='submit' className="btn btn-primary mb-3 text-center w-25"><span className="fw-bold fs-6">Pay </span>Rs.{final * Details.room * duration + final * Details.room * duration * 0.12}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}

export default PaymentPage