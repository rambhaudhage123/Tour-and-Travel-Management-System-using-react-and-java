import React from 'react'
import PrettyRating from "pretty-rating-react";
import { useNavigate, useParams } from 'react-router-dom'
import { useEffect } from 'react';
import UserService from '../../apis/UserService';
import { useState } from 'react';
import NavBar from '../Navbar-Footer/NavBar'

import { faStar, faStarHalfAlt } from "@fortawesome/free-solid-svg-icons";
import { faStar as farStar } from "@fortawesome/free-regular-svg-icons";

const DetailsPage = () => {
    const { id } = useParams()
    const navigate = useNavigate()
    const [hotelDetails, setDetials] = useState('')

    useEffect(() => {
        const getDetails = async () => {
            const data = await UserService.getCurrentHotel(id).then((response) => {
                setDetials(response.data)
            });
            console.log(data)
        }
        getDetails()
    }, [id])

    const handleClick = () => {
        navigate('/bookNowForm', { state: hotelDetails })
    }
    const icons = {
        star: {
            complete: faStar,
            half: faStarHalfAlt,
            empty: farStar,
        }
    };

    const colors = {
        star: ['#d9ad26', '#d9ad26']
    };
    return (
        <>
            <NavBar />
            <div className='text-center'>
                <img className="border border-primary rounded m-4 mb-4" src={hotelDetails.image} height="500px" alt='' />
                <h3 className='text-center'>{hotelDetails.hotelName}</h3>
            </div>

            <div className='m-5'>
                <h4 className='ml-5 fw-bolder'>About {hotelDetails.hotelName}</h4>
                <div className='border border-primary rounded m-3 p-3 bg-light text-dark'>
                    <h6 className=''>{hotelDetails.about}</h6>
                </div>
                <div className='m-2 w-80'>
                    <span>
                        Phone no.: {hotelDetails.phoneNo}<br />
                        Rooms available: {hotelDetails.noOfRooms}<br />
                        Rating: <PrettyRating value={hotelDetails.rating} icons={icons.star} setColors={colors.star} />
                    </span>
                </div>
                <div className='text-center m-4 '>
                    <button onClick={handleClick} className="btn btn-primary w-25 m-5">Book Room</button>
                </div>
            </div>

        </>
    )
}

export default DetailsPage