import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import UserService from '../../apis/UserService'
import { faStar, faStarHalfAlt } from "@fortawesome/free-solid-svg-icons";
import { faStar as farStar } from "@fortawesome/free-regular-svg-icons";
import PrettyRating from "pretty-rating-react";
import NavBar from '../Navbar-Footer/NavBar'

const HotelDetails = () => {
    const location = useLocation();
    const [hotels, setHotels] = useState([])
    const navigate = useNavigate()
    useEffect(() => {
        const getHotels = async () => {
            const data = await UserService.getHotel(location.state.city).then((response) => {
                setHotels(response.data)
            });
            console.log(data)
        }
        getHotels()

    }, [location.state.city])

    const icons = {
        star: {
            complete: faStar,
            half: faStarHalfAlt,
            empty: farStar,
        }
    };

    const colors = {
        star: ['#d9ad26', '#d9ad26']
    };
    return (
        <>
            <NavBar />
            <div className="container">
                <div className="column">

                    {hotels.map((hotel) => (
                        <div onClick={() => navigate(`/detailsPage/${hotel.hotel_id}`)} className="col-sm" key={hotel.hotel_id} >
                            <div className="card mt-3 mb-3">
                                <img className="card-img-top" src={hotel.image} height="400px" alt='' />
                                <div className="card-body">
                                    <h3 className="card-title">{hotel.hotelName}</h3>
                                    <p className="m-0 text-muted card-text">{hotel.city}, {hotel.location}</p>
                                    <span><PrettyRating value={hotel.rating} icons={icons.star} setColors={colors.star} /></span>

                                    <div className="float-right">
                                        <h5 className="text-dark p-2 pb-0 pt-0">
                                            <p className="m-0 text-muted fs-6">Per Night </p><strong>&#8377; {hotel.room_id}/.</strong></h5>
                                        <button type='submit' className="btn btn-primary fw-bold">View details</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    ))}
                </div>
            </div>
        </>
    )
}

export default HotelDetails