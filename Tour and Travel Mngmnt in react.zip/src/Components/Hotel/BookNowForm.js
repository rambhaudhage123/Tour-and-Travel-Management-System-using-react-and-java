import React from 'react'
import PhoneInput from 'react-phone-input-2'
import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import NavBar from '../Navbar-Footer/NavBar'

const BookNowForm = () => {
    const [firstName, setFirstName] = useState()
    const [lastName, setLastName] = useState()
    const [mobNo, setMobNo] = useState()
    const [email, setEmail] = useState()
    const [checkinDate, setCheckinDate] = useState()
    const [checkoutDate, setCheckoutDate] = useState()
    const [room, setRoom] = useState()
    const [guest, setGuest] = useState()
    const [roomType, setRoomType] = useState()

    const navigate = useNavigate()
    const location = useLocation();
    const hotelDetails = location.state;
    console.log(hotelDetails)
    const handleOnSubmit = (e) => {
        e.preventDefault()
        navigate('/paymentPage', { state: { firstName, lastName, mobNo, email, checkinDate, checkoutDate, room, guest, roomType, hotelDetails } })
    }
    const disablePastDateCheckIn = () => {
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, "0");
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const yyyy = today.getFullYear();
        return yyyy + "-" + mm + "-" + dd;
    };
    const disablePastDateCheckOut = () => {
        const today = new Date();
        const dd = String(today.getDate() + 1).padStart(2, "0");
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const yyyy = today.getFullYear();
        return yyyy + "-" + mm + "-" + dd;
    };
    return (
        <>
            <NavBar />
            <div className="text-center d-flex justify-content-center ">
                <div className='border border-primary rounded w-30 mt-3 bg-light text-dark'>
                    <form onSubmit={handleOnSubmit}>
                        <div className="d-flex text-center">
                            <div className="form-group m-2 d-inline-block mt-2">
                                <label for="fname"><span>First name </span>
                                    <input onChange={(e) => setFirstName(e.target.value)} className="form-control" id="fname" type="text" required />
                                </label>
                            </div>
                            <div className="form-group m-2 d-inline-block mt-2">
                                <label for="lname"><span>Last name </span>
                                    <input onChange={(e) => setLastName(e.target.value)} className="form-control" id="lname" type="text" required />
                                </label>
                            </div>
                        </div>
                        <div className="form-group m-2 ">
                            <label htmlFor="lname">
                                <PhoneInput
                                    country={'in'}
                                    value={mobNo}
                                    onChange={phone => setMobNo(phone)}
                                    required
                                />
                            </label>
                        </div>
                        <div className="form-group m-2">
                            <label for="lname"><span>Email </span>
                                <input onChange={(e) => setEmail(e.target.value)} className="form-control" id="lname" type="email" required />
                            </label>
                        </div>
                        <div className="form-group d-inline-block m-3">
                            <label for="checkin"><span>CHECK-IN</span>
                                <input onChange={(e) => setCheckinDate(e.target.value)} className="form-control" type="date" min={disablePastDateCheckIn()} required />
                            </label>
                        </div>
                        <div className="form-group d-inline-block ">
                            <label for="checkout"><span>CHECK-OUT</span>
                                <input onChange={(e) => setCheckoutDate(e.target.value)} className="form-control" type="date" min={disablePastDateCheckOut()} required />
                            </label>
                        </div>
                        <div className="form-group">
                            <label for="room"><span>Room</span>
                                <input onChange={(e) => setRoom(e.target.value)} className="form-control text-center" type="number" min='1' required />
                            </label>
                        </div>
                        <div className="form-group">
                            <label for="guest"><span>Guest</span>
                                <input onChange={(e) => setGuest(e.target.value)} className="form-control text-center" type="number" min='1' required />
                            </label>
                        </div>
                        <div className="form-group">
                            <label for="typeofroom"><span>Type of room</span>
                                <select onChange={(e) => setRoomType(e.target.value)} className="form-select text-center" required>
                                    <option selected value="">Type of Room</option>
                                    <option value="regular">Regular</option>
                                    <option value="Ac">AC</option>
                                    <option value="dulex">Dulex</option>
                                </select>
                            </label>
                        </div>
                        <div className="form-group">
                            <label for="room"><span>City</span>
                                <input value={location.state.city} className="form-control text-center" disabled />
                            </label>
                        </div>
                        <div className="form-group">
                            <label for="room"><span>Hotel Name</span>
                                <input value={hotelDetails.hotelName} className="form-control text-center" disabled />
                            </label>
                        </div>
                        <button type='submit' className="btn btn-primary m-3 w-75 fw-bolder fs-6 mb-5">Book Now!</button>
                    </form>
                </div>
            </div>
        </>
    )
}

export default BookNowForm