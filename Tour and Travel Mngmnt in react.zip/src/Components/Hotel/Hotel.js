import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router'
import NavBar from '../Navbar-Footer/NavBar'
const Hotel = () => {
  const [city, setCity] = useState('')
  const [checkinDate, setCheckinDate] = useState()
  const [checkoutDate, setCheckoutDate] = useState()
  const [room, setRoom] = useState()
  const [guest, setGuest] = useState()
  const [roomType, setRoomType] = useState()


  const navigate = useNavigate()

  const handleOnSubmit = (e) => {
    e.preventDefault()
    navigate(`/hotelDetailsPage`, { state: { city, checkinDate, checkoutDate, room, guest, roomType } })
  }
  const disablePastDateCheckIn = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const yyyy = today.getFullYear();
    return yyyy + "-" + mm + "-" + dd;
  };
  const disablePastDateCheckOut = () => {
    const today = new Date();
    const dd = String(today.getDate() + 1).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const yyyy = today.getFullYear();
    return yyyy + "-" + mm + "-" + dd;
  };
  return (
    <>
      <NavBar />
      <div className="text-center d-flex justify-content-center ">
        <div className='border border-primary rounded w-30 mt-5 bg-light text-dark'>
          <form onSubmit={handleOnSubmit}>
            <div className="form-group mt-3">
              <label for="city"><span>City or Location</span>
                <select class="form-select" onChange={(e) => setCity(e.target.value)} required>
                  <option selected value="">Select city</option>
                  <option value="pune">Pune</option>
                  <option value="nashik">Nashik</option>
                  <option value="nanded">Nanded</option>
                  <option value="banglore">Banglore</option>
                  <option value="mumbai">Mumbai</option>
                  <option value="nagpur">Nagpur</option>
                </select>

              </label>
            </div>
            <div className="form-group d-inline-block m-3">
              <label for="checkin"><span>CHECK-IN</span>
                <input className="form-control" type="date" onChange={(e) => setCheckinDate(e.target.value)} min={disablePastDateCheckIn()} required />
              </label>
            </div>
            <div className="form-group d-inline-block ">
              <label for="checkout"><span>CHECK-OUT</span>
                <input className="form-control" type="date" onChange={(e) => setCheckoutDate(e.target.value)} min={disablePastDateCheckOut()} required />
              </label>
            </div>
            <div className="form-group">
              <label for="room"><span>Room</span>
                <select class="form-select" onChange={(e) => setRoom(e.target.value)} required>
                  <option selected value="">Room No.</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </label>
            </div>
            <div className="form-group">
              <label for="guest"><span>Guest</span>
                <select onChange={(e) => setGuest(e.target.value)} class="form-select" required>
                  <option selected value="">No. of guest</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </label>
            </div>
            <div className="form-group">
              <label for="typeofroom"><span>Type of room</span>
                <select onChange={(e) => setRoomType(e.target.value)} class="form-select" required>
                  <option selected value="">Type of Room</option>
                  <option value="regular">Regular</option>
                  <option value="Ac">AC</option>
                  <option value="dulex">Dulex</option>
                </select>
              </label>
            </div>

            <button type='submit' className="btn btn-primary m-3 w-75">Book Now!</button>
          </form>
        </div>
      </div>
    </>
  )
}

export default Hotel