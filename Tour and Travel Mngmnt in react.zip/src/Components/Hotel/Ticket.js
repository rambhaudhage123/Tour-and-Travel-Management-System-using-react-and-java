import React from 'react'
import { useEffect } from 'react'
import UserService from '../../apis/UserService'
import { useLocation, useNavigate } from 'react-router-dom'

const Ticket = () => {
    const current = new Date();
    const date = `${current.getDate()}/${current.getMonth() + 1}/${current.getFullYear()}`;
    console.log(date)
    const location = useLocation();
    const navigate = useNavigate();
    const paymentDetails = location.state;

    if (paymentDetails.Details.roomType === "Ac") {
        var finalPrice = paymentDetails.Details.hotelDetails.room_id + 1000;
    } else if (paymentDetails.Details.roomType === "dulex") {
        // eslint-disable-next-line no-redeclare
        var finalPrice = paymentDetails.Details.hotelDetails.room_id + 1500;
    } else {
        // eslint-disable-next-line no-redeclare
        var finalPrice = paymentDetails.Details.hotelDetails.room_id;
    }
    //List of data to send in database
    const invoiceNumber = paymentDetails.invoiceNo;
    const personName = paymentDetails.Details.firstName + paymentDetails.Details.lastName;
    const personNameOnCard = paymentDetails.personName;
    const personEmail = paymentDetails.Details.email;
    const personPhoneNo = paymentDetails.Details.mobNo;
    const cardDetail = paymentDetails.cardNo;
    const hotelID = paymentDetails.Details.hotelDetails.hotel_id;
    const hotelNameToDatabase = paymentDetails.Details.hotelDetails.hotelName;
    const hotelphoneNoToDatabase = paymentDetails.Details.hotelDetails.phoneNo;
    const checkinDateToDatabase = paymentDetails.Details.checkinDate;
    const checkOutDateToDatabase = paymentDetails.Details.checkoutDate;
    const noOfGuest = paymentDetails.Details.guest;
    const noOfRoom = paymentDetails.Details.room;
    const objectToSend = {
        invoiceNumber,
        personName,
        personNameOnCard,
        personEmail,
        personPhoneNo,
        cardDetail,
        hotelID,
        hotelNameToDatabase,
        hotelphoneNoToDatabase,
        checkinDateToDatabase,
        checkOutDateToDatabase,
        noOfGuest,
        noOfRoom,
        finalPrice
    };
    console.log(objectToSend)

    useEffect(() => {
        const sendData = async () => {
            const data = await UserService.sendData(objectToSend).then();
            console.log(data)
        }
        sendData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
        <>
            <div className="container mt-5">
                <div className="row gutters">
                    <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div className="card">
                            <div className="card-body p-0">
                                <div className="invoice-container">
                                    <div className="row gutters">
                                        <div className="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                            <div className="invoice-details">
                                                <address>
                                                    {paymentDetails.personName}<br />
                                                    <p className="m-0 text-muted">
                                                        {paymentDetails.cardNo}
                                                    </p>
                                                </address>
                                            </div>
                                        </div>
                                        <div className="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                                            <div className="invoice-details">
                                                <div className="invoice-num">
                                                    <div>Invoice - #{paymentDetails.invoiceNo}</div>
                                                    <div>{date}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="invoice-body">
                                    <div className="row gutters">
                                        <div className="col-lg-12 col-md-12 col-sm-12">
                                            <div className="table-responsive">
                                                <table className="table custom-table m-0">
                                                    <thead>
                                                        <tr>
                                                            <th></th>
                                                            <th>Date</th>
                                                            <th>No of rooms</th>
                                                            <th>No of guests</th>
                                                            <th>No of days</th>
                                                            <th>Type of room</th>
                                                            <th>Sub Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                {paymentDetails.Details.hotelDetails.hotelName}
                                                                <p className="m-0 text-muted">
                                                                    {paymentDetails.Details.hotelDetails.city}
                                                                </p>
                                                            </td>
                                                            <td>{date}</td>
                                                            <td>{paymentDetails.Details.room}</td>
                                                            <td>{paymentDetails.Details.guest}</td>
                                                            <td>{paymentDetails.duration}</td>
                                                            <td>{paymentDetails.Details.roomType.toUpperCase()}</td>
                                                            <td>{finalPrice * paymentDetails.Details.room} Rs.</td>
                                                        </tr>

                                                        <tr>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td colSpan="2">
                                                                <p>
                                                                    Subtotal<br />
                                                                    Tax 12%<br />
                                                                </p>
                                                                <h5 className="text-success"><strong>Grand Total</strong></h5>
                                                            </td>
                                                            <td>
                                                                <p>
                                                                    {finalPrice * paymentDetails.Details.room * paymentDetails.duration} Rs.<br />
                                                                    {finalPrice * paymentDetails.Details.room * paymentDetails.duration * 0.12} Rs.<br />
                                                                </p>
                                                                <h5 className="text-success"><strong>{finalPrice * paymentDetails.Details.room * paymentDetails.duration
                                                                    + finalPrice * paymentDetails.Details.room * paymentDetails.duration * 0.12} Rs.</strong></h5>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="text-center">
                <button className="btn btn-secondary mt-3" onClick={() => { window.print(); return false; }}>Print Ticket</button>
                <button className="btn btn-primary mt-3" onClick={() => navigate(`/home`)}>Home</button>
            </div>
        </>
    )
}

export default Ticket