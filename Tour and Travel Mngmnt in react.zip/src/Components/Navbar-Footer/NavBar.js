import React from 'react'
import "./navbar.css"
import { Outlet, Link, useNavigate } from 'react-router-dom'

const NavBar = ({ Data }) => {
    const navigate = useNavigate()
    const handleDashClick = () => {
        navigate(`/dashboard`, { state: { Data } })
    }
    return (
        <>
            <div className="topnav">
                <Link className="active" to="/home">IVL Travel</Link>
                <Link to="/hotel">Hotel</Link>
                <Link to="/flight">Flight</Link>
                <Link to="/AboutUs">AboutUs</Link>
                <div className="topnav-right">
                    <a onClick={handleDashClick} href='dashboard'>Dashboard</a>
                    <Link to="/">Logout</Link>
                </div>
            </div>
            <Outlet />
        </>
    )
}

export default NavBar