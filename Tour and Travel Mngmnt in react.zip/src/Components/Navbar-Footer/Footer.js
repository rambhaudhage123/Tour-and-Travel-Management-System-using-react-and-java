import React from 'react'
import "./footer.css"
const Footer = () => {
  return (
    <div className='footer'>Footer for the website</div>
  )
}

export default Footer;