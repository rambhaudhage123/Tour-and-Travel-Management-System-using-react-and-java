import NavBar from "../Navbar-Footer/NavBar";

function AboutUs() {
    return (
        <>
            <NavBar />
            <div className="container aboutus">
                <div className="row">
                    <div>
                        <h1 className="display-4 text-center mt-5">About Us </h1>
                        <p className="lead text-justify text-center">IVL INTERNS WORKING ON FINAL PROJECT</p>
                    </div>
                </div>
                <div className="bg-primary text-white text-center border rounded p-2">
                    <h1 className="display-7">Our Team</h1>
                </div>
                <div className="row mb-5">
                    <div className="col-md-4 col-12 mx-auto my-2">
                        <div className="card border-0 shadow-lg p-4">
                            <img src="https://i.im.ge/2022/07/11/unUtCz.jpg" className="card-img-top" alt="director" />
                            <div className="card-body">
                                <h5 className="card-title mb-0">TEAM MEMBER</h5>
                                <div className="card-text text-black-50">Sahil Dange
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-12 mx-auto my-2">
                        <div className="card border-0 shadow-lg p-4">
                            <img src="https://i.im.ge/2022/07/11/unUyv6.jpg" className="card-img-top" alt="director" />
                            <div className="card-body">
                                <h5 className="card-title mb-0">TEAM MEMBER</h5>
                                <div className="card-text text-black-50">Shivam Chandwadkar
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-12 mx-auto my-2">
                        <div className="card border-0 shadow-lg p-4">
                            <img src="https://i.im.ge/2022/07/11/unUE6K.jpg" className="card-img-top" alt="director" />
                            <div className="card-body">
                                <h5 className="card-title mb-0">TEAM MEMBER</h5>
                                <div className="card-text text-black-50">Radhika Parikh
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row mb-6">
                        <div className="col-md-4 col-12 mx-auto my-2">

                            <div className="card border-0 shadow-lg p-4">
                                <img src="https://i.im.ge/2022/07/21/FSxkeh.jpg" className="card-img-top" alt="director" />
                                <div className="card-body">
                                    <h5 className="card-title mb-0">TEAM MEMBER</h5>
                                    <div className="card-text text-black-50">Nikhil Rathod
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4 col-12 mx-auto my-2">
                            <div className="card border-0 shadow-lg p-4">
                                <img src="https://i.im.ge/2022/07/21/FS3Tef.jpg" className="card-img-top" alt="director" />
                                <div className="card-body">
                                    <h5 className="card-title mb-0">TEAM MEMBER</h5>
                                    <div className="card-text text-black-50">Rambhau Dhage
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};
export default AboutUs;