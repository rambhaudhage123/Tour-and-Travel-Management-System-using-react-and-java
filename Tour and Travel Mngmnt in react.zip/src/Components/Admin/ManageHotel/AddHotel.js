import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import UserService from'../../../apis/UserService'
import NavBarSa from '../NavBarSa';
const AddBook = () => {
  const navigate = useNavigate();
  const [toUpdateHotel, settoUpdateHotel] = useState({
    hotel_id: '',
    hotelName: '',
    phoneNo: '',
    location: '',
    city: '',
    rating: '',
    noOfRooms: '',
    room_id: '',
    image: '',
    about: ''
  });

  const handlerChange = (event) => {
    const name = event.target.name;
    settoUpdateHotel({ ...toUpdateHotel, [name]: event.target.value });
  }

  const handleSubmit = (event) => {
    event.preventDefault();

    UserService.addHotel(toUpdateHotel);
    settoUpdateHotel({
      hotel_id: '',
      hotelName: '',
      phoneNo: '',
      location: '',
      city: '',
      rating: '',
      noOfRooms: '',
      room_id: '',
      image: '',
      about: ''
    })
    navigate('/admin/HotelList')
  }

  return (
    <><NavBarSa></NavBarSa>
    <h1 class="display-4 text-center">Add Hotel</h1>
      <form onSubmit={handleSubmit}>
        <div className="container-sm border mt-4 rounded">
          <div className="form-group mt-4">
            <label htmlFor="hotelName">Hotel Name</label>
            <input type="text" name="hotelName" value={toUpdateHotel.hotelName} onChange={handlerChange} required="required" placeholder='Enter hotel name' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="phoneNo">Hotel phoneNo</label>
            <input type="text" name="phoneNo" value={toUpdateHotel.phoneNo} onChange={handlerChange} required="required" placeholder='Enter hotel name' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="location">Hotel Location</label>
            <input type="text" name="location" value={toUpdateHotel.location} onChange={handlerChange} required="required" placeholder='Enter area' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="city">Hotel city</label>
            <input type="text" name="city" value={toUpdateHotel.city} onChange={handlerChange} required="required" placeholder='Enter area' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="rating">Hotel rating</label>
            <input type="range" min="0" max="5" step="0.5" name="rating" value={toUpdateHotel.rating} onChange={handlerChange} required="required" placeholder='Enter rating' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="noOfRooms">No of Rooms</label>
            <input type="number" name="noOfRooms" value={toUpdateHotel.noOfRooms} onChange={handlerChange} required="required" placeholder='Enter no. of room ' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="roomid">Price</label>
            <input type="number" name="room_id" value={toUpdateHotel.room_id} onChange={handlerChange} required="required" placeholder='Enter room id' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="img">image url</label>
            <input type="text" name="image" value={toUpdateHotel.image} onChange={handlerChange} required="required" placeholder='Enter price ' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="about">about</label>
            <input type="text" name="about" value={toUpdateHotel.about} onChange={handlerChange} required="required" placeholder='Enter about' className="form-control"></input>
          </div>
          <div className="form-group text-center mb-4">
            <input type="submit" value="Add Hotel" className="btn btn-primary w-50 mt-2" />
          </div>
        </div>
      </form>
    </>
  )
}

export default AddBook