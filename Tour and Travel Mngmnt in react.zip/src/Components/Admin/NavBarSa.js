import React from 'react'

import { Outlet, Link } from 'react-router-dom'

function NavBarSa() {


        return (
        <>
            <nav class="navbar navbar-expand-lg navbar-light bg-light" >
                <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
 
          <li>
            <Link to="/admin" class="nav-link" >Manage User</Link>
          </li>
          <li>
            <Link to="/admin/HotelList" class="nav-link" >Manage Hotel</Link>
          </li>
          <li>
            <Link to="/admin/FlightList" class="nav-link" >Manage Flight</Link>
          </li>
          <div >
           <li >
            <Link to="/" class="nav-link" id="logout">Logout</Link>
          </li>
          </div>
        </ul>
        </div>

</nav>
<Outlet />
          </>
               
        );
    
}

export default NavBarSa;