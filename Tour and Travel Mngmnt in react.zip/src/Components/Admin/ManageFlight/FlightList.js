import React, { useEffect, useState } from 'react'


import FlightService from '../../../apis/FlightService';
import NavBarSa from '../NavBarSa';
import { Navigate, useNavigate } from 'react-router';
const BookList = () => {
    const navigate = useNavigate();
    const [Flights, setFlights] = useState([]);
    const [toUpdateFlight, settoUpdateFlight] = useState({
        code:'',
      arrival:'',
      arrivalTime:'',
      depart:'',
      departTime:'',
      fromCity:'',
      price:0,
      toCity:'',
      flightImg:','
    });

    useEffect(() => {
        FlightService .getAllFlights().then((response) => {
            setFlights(response.data)
        });
    }, []);

    const handlerChange = (event) => {
        const name = event.target.name;
        settoUpdateFlight({ ...toUpdateFlight, [name]: event.target.value });
    }
    const convertarrivalTime = ()=> {
        var timeStr=toUpdateFlight.arrivalTime;
        const [time, modifier] = timeStr.split(' ');
        let [hours, minutes] = time.split(':');
        if (hours === '12') {
           hours = '00';
        }
        if (modifier === 'PM') {
           hours = parseInt(hours, 10) + 12;
        }
                        
        var newdate=hours + ':' + minutes;
        alert(newdate);
        settoUpdateFlight({ ...toUpdateFlight, 'arrivalTime': newdate });
     };
     const convertDepartTime =()=> {
        var timeStr=toUpdateFlight.departTime;
        const [time, modifier] = timeStr.split(' ');
        let [hours, minutes] = time.split(':'||'.');
        if (hours === '12') {
           hours = '00';
        }
        if (modifier === 'PM') {
           hours = parseInt(hours, 10) + 12;
        }
                        
        var newdate=hours + ':' + minutes;
        toUpdateFlight.departTimeTime=newdate;
     };
    
    
    return (
        <>
       <NavBarSa></NavBarSa>
            <h1 class="display-4 text-center mt-3">Manage Flights</h1>
        <div>
        <button type="button" onClick={() => navigate("/admin/addFlight") }class="btn btn-primary ms-5">Add Flight</button>
        </div>  
            <div className="mt-5 p-4">
                <table className="table table-striped">
                    <thead className="table-dark">
                        <tr className="text-center">
                            <th >Flight Code</th>
                            <th >Arrival Date</th>
                            <th >Arrival Time</th>
                            <th >Depart Date</th>
                            <th >Depart Time</th>
                            <th >From</th>
                            <th >To</th>
                            <th >Image</th>
                            <th >Price</th>
                            <th >Actions</th>
                        </tr>
                    </thead>
                    <tbody className="tbody">
                        {
                            Flights.map(Flights => {
                                return (
                                    <tr className="text-center" key={Flights.code}>

                                        {/* <td><button data-bs-toggle="modal" data-bs-target="#updateBookModal" onClick={() => setToUpdateBook(book)} type="button" className="btn btn-primary">Edit Price</button></td>
                                        <td><button onClick={() => deleteBook(book.isbn)} type="button" className="btn btn-danger">Remove</button></td> */}
                                        <td>{Flights.code}</td>
                                        <td>{Flights.arrival}</td>
                                        <td>{Flights.arrivalTime}</td>
                                        <td>{Flights.depart}</td>
                                        <td>{Flights.departTime}</td>
                                        <td>{Flights.fromCity}</td>
                                        <td>{Flights.toCity}</td>
                                        <td><img width="2px" height="2px" src={Flights.flightImg}></img></td>
                                        <td>{Flights.price}</td>
                                        <td>
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#updateBookModal" class="btn btn-primary mx-1" onClick={(event) => settoUpdateFlight(Flights)}>Edit</button>
                                           
                                        </td>

                                    </tr>
                                )
                            })
                        }
                    </tbody >
                </table >
            </div >






            <div className="modal fade" id="updateBookModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Update Flight</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            <form onSubmit={() => FlightService.updateFlight(toUpdateFlight.code,toUpdateFlight)}>
                            <div className="form-group mt-4">
            <label htmlFor="hotelName">Flight code</label>
            <input type="text" name="code" value={toUpdateFlight.code} onChange={handlerChange} disabled required="required" placeholder='Enter Flight code' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="phoneNo">arrival Date</label>
            <input type="date" name="arrival" value={toUpdateFlight.arrival} onChange={handlerChange} required="required" placeholder='Enter Arrival date' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="location">arrival Time</label>
            <input type="text" name="arrivalTime" value={toUpdateFlight.arrivalTime} onChange={handlerChange} required="required" placeholder='Enter Arrival Time' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="city">departure Date</label>
            <input type="date" name="depart" value={toUpdateFlight.depart} onChange={handlerChange}  required="required" placeholder='Enter Depart date' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="rating">Departure Time</label>
            <input type="text" name="departTime" value={toUpdateFlight.departTime}onChange={handlerChange} required="required" placeholder='Enter Depart time' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="noOfRooms">From</label>
            <input type="text" name="fromCity" value={toUpdateFlight.fromCity} onChange={handlerChange} required="required" placeholder='From City' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="roomid">To</label>
            <input type="text" name="toCity" value={toUpdateFlight.toCity} onChange={handlerChange} required="required" placeholder='To City' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="img">Price</label>
            <input type="number" name="price" value={toUpdateFlight.price} onChange={handlerChange} required="required" placeholder='Enter price ' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="about">Image Url</label>
            <input type="text" name="flightImg" value={toUpdateFlight.flightImg} onChange={handlerChange} required="required" placeholder='Enter Image Url' className="form-control"></input>
          </div>
                                <div className="form-group text-center">
                                    <button type="submit" className="btn btn-primary w-40 mt-2" data-bs-dismiss="modal">Save</button>
                                    <button type="button" class="btn btn-secondary mx-1" className="btn btn-primary w-40 mt-2" data-bs-dismiss="modal">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default BookList