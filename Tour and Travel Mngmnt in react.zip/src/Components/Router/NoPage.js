import React from 'react'
import NavBar from '../Navbar-Footer/NavBar'

const NoPage = () => {
  return (
    <>
      <NavBar />
      <div>page not found</div>
    </>
  )
}

export default NoPage