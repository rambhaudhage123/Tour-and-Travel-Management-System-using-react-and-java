import React from 'react'
import Home from '../Home/Home';
import Hotel from '../Hotel/Hotel';
import Showcase from '../Flight/Showcase';
import HotelDetails from '../Hotel/HotelDetails';
import DetailsPage from '../Hotel/DetailsPage';
import BookNowForm from '../Hotel/BookNowForm';
import NoPage from './NoPage';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import PaymentPage from '../Hotel/PaymentPage';
import Ticket from '../Hotel/Ticket';
import Login from '../LoginPage/Login';
import Dashboard from '../Dashboard/Dashboard';
import SuperAdmin from '../SuperAdmin/Navigation';
import AddAdmin from  '../SuperAdmin/ADMIN/Addadmin';
import User from '../SuperAdmin/User/UserList';
import MHotel from '../SuperAdmin/ManageHotel/HotelList';
import AddUser from '../SuperAdmin/User/AddUser';
import AddHotel from '../SuperAdmin/ManageHotel/AddHotel';
import MFlight from '../SuperAdmin/ManageFlight/FlightList';
import AddFlight from '../SuperAdmin/ManageFlight/AddFlight';
import User_A from '../Admin/User/UserList';
import AddUser_A from '../Admin/User/AddUser';
import MHotel_A from '../Admin/ManageHotel/HotelList';
import AddHotel_A from '../Admin/ManageHotel/AddHotel';
import MFlight_A from '../Admin/ManageFlight/FlightList';
import AddFlight_A from '../Admin/ManageFlight/AddFlight';
import Search from '../Flight/Search'
import BookingForm from '../Flight/BookingForm'
import FlightPaymentPage from '../Flight/FlightPaymentPage'
import FlightTicket from '../Flight/FlightTicket'
import AboutUs from '../Aboutus/AboutUs';

const Router = () => {
    return (
        <>
            <BrowserRouter>
                <Routes>
                    <Route index element={<Login />} />
                    <Route path="home" element={<Home />} />
                    <Route path="hotel" element={<Hotel />} />
                    <Route path="/AboutUs" element={<AboutUs />} />
                    <Route path="flight" element={<Showcase />} />
                    <Route path="hotelDetailsPage" element={<HotelDetails />} />
                    <Route path="detailsPage/:id" element={<DetailsPage />} />
                    <Route path="bookNowForm" element={<BookNowForm />} />
                    <Route path="paymentPage" element={<PaymentPage />} />
                    <Route path="ticket" element={<Ticket />} />


                    <Route path="superadmin" element={<SuperAdmin />} />
                    <Route path="/superadmin/addAdmin" element={<AddAdmin />} />
                    <Route path="/superadmin/User" element={<User />} />
                    <Route path="/superadmin/addUser" element={<AddUser />} />
                    <Route path="/superadmin/HotelList" element={<MHotel />} />
                    <Route path="/superadmin/addHotel" element={<AddHotel />} />
                    <Route path="/superadmin/FlightList" element={<MFlight />} />
                    <Route path="/superadmin/addFlight" element={<AddFlight />} />

                    <Route path="admin" element={<User_A />} />
                    <Route path="/admin/addUser" element={<AddUser_A />} />
                    <Route path="/admin/HotelList" element={<MHotel_A />} />
                    <Route path="/admin/addHotel" element={<AddHotel_A />} />
                    <Route path="/admin/FlightList" element={<MFlight_A />} />
                    <Route path="/admin/addFlight" element={<AddFlight_A />} />



                    <Route path="dashboard" element={<Dashboard />} />

                    <Route path="/search" element={<Search />} />
                    <Route path="/bookingform" element={<BookingForm />} />
                    <Route path="/flightPaymentPage" element={<FlightPaymentPage />} />
                    <Route path="flightticket" element={<FlightTicket />} />
                    <Route path="*" element={<NoPage />} />
                </Routes>
            </BrowserRouter>
        </>
    )
}

export default Router