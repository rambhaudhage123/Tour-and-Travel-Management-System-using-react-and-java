import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import "./login.css"
import UserService from '../../apis/UserService'

const Login = () => {
    let [authMode, setAuthMode] = useState("signin")

    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("")

    const [userDetails, setUserDetails] = useState({
        fullName: '',
        phoneNo: '',
        username: '',
        password: '',
        role: 'USER',
        status: 0
    });

    const handlerChange = (event) => {
        const name = event.target.name;
        setUserDetails({ ...userDetails, [name]: event.target.value });
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(userDetails);
        UserService.addUser(userDetails).then((response) => {
            console.log(response?.data?.username);
        });
        setUserDetails({
            fullName: '',
            phoneNo: '',
            username: '',
            password: ''
        })
    }

    const changeAuthMode = () => {
        setAuthMode(authMode === "signin" ? "signup" : "signin")
    }

    const navigate = useNavigate()

    const handleOnSubmit = (e) => {
        e.preventDefault()
        UserService.getAllUsers().then((response) => {
            for (let i = 0; i < response.data.length; i++) {
                if (username === response?.data[i].username && password === response?.data[i].password) {
                    if (response?.data[i].role === "USER") {
                        setError("");
                        if (response?.data[i].status === true) {
                            setError("User is Locked contact Administrator");
                        }
                        else {
                            const dataToDashboard = response?.data[i];
                            navigate('/home', { state: { dataToDashboard } })
                        }
                    }
                    if (response?.data[i].role === "SUPERADMIN") {
                        navigate('/superadmin')
                    }
                    if (response?.data[i].role === "ADMIN") {
                        navigate('/admin')
                    }
                }
            }
        });

    }

    if (authMode === "signin") {
        return (
            <div className="Auth-form-container">
                <form onSubmit={handleOnSubmit} className="Auth-form">
                    <div className="Auth-form-content">
                        <h3 className="Auth-form-title">Log In</h3>
                        <div className="text-center">
                            Not registered yet?{" "}
                            <span className="link-primary" onClick={changeAuthMode}>
                                Sign Up
                            </span>
                        </div>
                        <div className="form-group mt-3">
                            <label>Email address</label>
                            <input
                                onChange={(e) => setUsername(e.target.value)}
                                type="email"
                                className="form-control mt-1"
                                placeholder="Enter email"
                            />
                        </div>
                        <div className="form-group mt-3">
                            <label>Password</label>
                            <input
                                onChange={(e) => setPassword(e.target.value)}
                                type="password"
                                className="form-control mt-1"
                                placeholder="Enter password"
                            />
                        </div>
                        <label>{error}</label>
                        <div className="d-grid gap-2 mt-3">
                            <button type="submit" className="btn btn-primary">
                                Login
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        )
    }

    return (
        <div className="Auth-form-container">
            <form onSubmit={handleSubmit} className="Auth-form">
                <div className="Auth-form-content">
                    <h3 className="Auth-form-title">Registration</h3>
                    <div className="text-center">
                        Already registered?{" "}
                        <span className="link-primary" onClick={changeAuthMode}>
                            Log In
                        </span>
                    </div>
                    <div className="form-group mt-3">
                        <label>Full Name</label>
                        <input
                            name='fullName'
                            value={userDetails.fullName} onChange={handlerChange}
                            type="text"
                            className="form-control mt-1"
                            placeholder="Full name"
                        />
                    </div>
                    <div className="form-group mt-3">
                        <label>Phone no</label>
                        <input
                            name='phoneNo'
                            value={userDetails.phoneNo} onChange={handlerChange}
                            type="tel"
                            className="form-control mt-1"
                            placeholder="Phone number"
                        />
                    </div>
                    <div className="form-group mt-3">
                        <label>Email address</label>
                        <input
                            name='username'
                            value={userDetails.username} onChange={handlerChange}
                            type="email"
                            className="form-control mt-1"
                            placeholder="Email Address"
                        />
                    </div>
                    <div className="form-group mt-3">
                        <label>Password</label>
                        <input
                            name='password'
                            value={userDetails.password} onChange={handlerChange}
                            type="password"
                            className="form-control mt-1"
                            placeholder="Password"
                            minLength='5'
                        />
                    </div>
                    <div className="d-grid gap-2 mt-3">
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    )
}

export default Login