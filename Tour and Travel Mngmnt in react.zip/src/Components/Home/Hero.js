import React from 'react'
const Hero = () => {
    return (
        <>
            <div className="hero">
                <div className="intro">
                    <h1 data-aos="fade-up" data-aos-delay="">Travel to the most beautiful places in the world <span className="typed-words"></span></h1>
                </div>

            </div>

        </>
    )
}

export default Hero