import React from 'react'
import CountUp from 'react-countup'
const Achive = () => {
  return (
    <div className="untree_co-section count-numbers bg-primary py-5">
        <div className="container">
            <div className="row">
                <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                    <div className="counter-wrap">
                        <div className="counter">
                            <CountUp
                            end={921}
                            duration={5}
                            />
                        </div>
                        <span className="caption"># of Travels</span>
                    </div>
                </div>
                <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                    <div className="counter-wrap">
                        <div className="counter">
                            <CountUp
                            end={841}
                            duration={5}
                            />
                        </div>
                        <span className="caption"># of Clients</span>
                    </div>
                </div>
                <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                    <div className="counter-wrap">
                        <div className="counter">
                            <CountUp
                            end={100}
                            duration={5}
                            />
                        </div>
                        <span className="caption"># of Employees</span>
                    </div>
                </div>
                <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                    <div className="counter-wrap">
                        <div className="counter">
                            <CountUp
                            end={120}
                            duration={5}
                            />
                        </div>
                        <span className="caption"># of Countries</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

  )
}

export default Achive