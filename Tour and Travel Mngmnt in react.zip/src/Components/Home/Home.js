import React, { useEffect, useState } from 'react'
import '../../App.css';
import '../bootstrap.css'
import Hero from './Hero';
import { Link, useLocation } from 'react-router-dom'
import img from '../images/img_1.jpg'
import taj from '../images/taj.jpg'
import tajhotel from '../images/tajhotel.jpg'
import redfort from '../images/redfort.jpg'
import banglore from '../images/banglore.jpg'
import Achive from './Achive';
import Services from './Services';
import Footer from '../Navbar-Footer/Footer';
import NavBar from '../Navbar-Footer/NavBar'

const Home = () => {
    const [Data, setData] = useState('');
    const location = useLocation();
    const data = location.state;
    useEffect(() => {
        setData(data)
    }, [data]);
    console.log(Data)
    return (
        <div className="App">
            <NavBar Data={Data} />
            <Hero />
            <div className="untree_co-section">
                <div className="container">
                    <div className="row justify-content-center text-center mb-5">
                        <div className="col-lg-6">
                            <h2 className="section-title text-center mb-3">Safar karo, suffer nahi.</h2>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                            <div className="media-1">
                                <Link to="#" className="d-block mb-3"><img src={taj} alt="mage" className="img-fluid" /><noscript><img src={taj} alt="mage" className="img-fluid" /></noscript></Link>
                                <div className="d-flex">
                                    <div>
                                        <h3><Link to="#">Taj Mahal</Link> </h3>
                                    </div>
                                </div>
                                <span className="d-flex align-items-center loc">
                                    <span className="icon-room mr-2"></span>
                                    <span>Agra</span>
                                </span>
                            </div>
                        </div>
                        <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                            <div className="media-1">
                                <Link to="#" className="d-block mb-3"><img src={tajhotel} alt="mage" className="img-fluid" /><noscript><img src={tajhotel} alt="mage" className="img-fluid" /></noscript></Link>
                                <div className="d-flex">
                                    <div>
                                        <h3><Link to="#">Taj Hotel</Link> </h3>
                                    </div>
                                </div>
                                <span className="d-flex align-items-center loc">
                                    <span className="icon-room mr-2"></span>
                                    <span>Mumbai</span>
                                </span>
                            </div>
                        </div>
                        <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                            <div className="media-1">
                                <Link to="#" className="d-block mb-3"><img src={redfort} alt="mage" className="img-fluid" /><noscript><img src={redfort} alt="mage" className="img-fluid" /></noscript></Link>
                                <div className="d-flex">
                                    <div>
                                        <h3><Link to="#">Red Fort</Link> </h3>
                                    </div>
                                </div>
                                <span className="d-flex align-items-center loc">
                                    <span className="icon-room mr-2"></span>
                                    <span>Delhi</span>
                                </span>
                            </div>
                        </div>
                        <div className="col-6 col-sm-6 col-md-6 col-lg-3">
                            <div className="media-1">
                                <Link to="#" className="d-block mb-3"><img src={banglore} alt="mage" className="img-fluid" /><noscript><img src={banglore} alt="mage" className="img-fluid" /></noscript></Link>
                                <div className="d-flex">
                                    <div>
                                        <h3><Link to="#">Vidhana Soudha</Link> </h3>
                                    </div>
                                </div>
                                <span className="d-flex align-items-center loc">
                                    <span className="icon-room mr-2"></span>
                                    <span>Bangalore</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="untree_co-section">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-5">
                            <h2 className="title-with-bg text-lg-right overlap-right mb-5">
                                <span>We Travel Not To Escape Life But for Life not to Escape Us.</span>
                            </h2>
                            <div className="row">
                                <div className="col-lg-8 ml-auto text-lg-right">
                                    <p>At IVL Travel, you can find the best of deals and cheap air tickets to any place you want by booking your tickets on our website or app. Being India's leading website for hotel, flight, and holiday bookings, MakeMyTrip helps you book flight tickets that are affordable and customized to your convenience.</p>
                                    <p className="mb-4">You can get a hold of the cheapest flight of your choice today while also enjoying the other available options for your travel needs with us.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <figure className="img-play-video">

                                <img src={img} alt="mage" className="img-fluid" /><noscript><img src={img} alt="mage" class="img-fluid" /></noscript>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <Achive />
            <Services />
            <Footer />
        </div>
    )
}

export default Home