import React from 'react'
import AdminList from './ADMIN/AdminList';
import User from './User/UserList';
import AddUser from './User/AddUser';
import { BrowserRouter,Routes, Route , useNavigate} from "react-router-dom";
import NavBarSa from './NavBarSa';
import HotelList from './ManageHotel/HotelList';
import AddHotel from './ManageHotel/AddHotel';
import AddAdmin from './ADMIN/Addadmin';
import MFlight from './ManageFlight/FlightList';
import AddFlight from './ManageFlight/AddFlight'
function Navigation() {
    const navigate = useNavigate();
  
  return (

      <Routes>
        <Route path="/" element={<NavBarSa/>}>
        <Route index element={<AdminList/>} />
        <Route path="/superadmin/addAdmin" element={<AddAdmin/>} />
          <Route path="/superadmin/User" element={<User/>} />
          <Route path="/superadmin/addUser" element={<AddUser/>} />
          <Route path="/superadmin/HotelList" element={<HotelList/>} />
          <Route path="/superadmin/addHotel" element={<AddHotel/>} />
          <Route path="/superadmin/FlightList" element={<MFlight/>} />
          <Route path="/superadmin/addFlight" element={<AddFlight/>} />
        </Route>
      </Routes>

  )
}

export default Navigation