import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import UserService from'../../../apis/UserService'
import NavBarSa from '../NavBarSa';
const AddBook = () => {
  const navigate = useNavigate();
  const [toUpdateUser, settoUpdateUser] = useState({
    fullName: '',
    username: '',
    password: '',
    role: 'USER',
    status: 0
  });

  const handlerChange = (event) => {
    const name = event.target.name;
    settoUpdateUser({ ...toUpdateUser, [name]: event.target.value });
  }

  const handleSubmit = (event) => {
    event.preventDefault();

    UserService.addUser(toUpdateUser);
    settoUpdateUser({
      fullName: '',
      username: '',
      password: '',
      role: 'USER',
      status: 0
    })
    navigate('/superadmin/User')
  }

  return (
    <>            <NavBarSa></NavBarSa>
    <h1 class="display-4 text-center">Add User</h1>
      <form onSubmit={handleSubmit}>
        <div className="container-sm border mt-4 rounded">
          <div className="form-group mt-4">
            <label htmlFor="hotelName">Full Name</label>
            <input type="text" name="fullName" value={toUpdateUser.fullName} onChange={handlerChange} required="required" placeholder='Enter Full Name' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="phoneNo">Username</label>
            <input type="email" name="username" value={toUpdateUser.username} onChange={handlerChange} required="required" placeholder='Enter Username' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="location">Password</label>
            <input type="text" name="password" value={toUpdateUser.password} onChange={handlerChange} required="required" placeholder='Enter Password' className="form-control"></input>
          </div>
          <div className="form-group text-center mb-4">
            <input type="submit" value="Add User" className="btn btn-primary w-50 mt-2" />
          </div>
        </div>
      </form>
    </>
  )
}

export default AddBook