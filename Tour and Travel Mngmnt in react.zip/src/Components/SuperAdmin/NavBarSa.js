import React from 'react'

import { Outlet, Link } from 'react-router-dom'

function NavBarSa() {


        return (
        <>
            <nav class="navbar navbar-expand-lg navbar-light bg-light" >
                <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <Link to="/superadmin"  class="nav-link">Manage Admin</Link>
          </li>
          <li>
            <Link to="/superadmin/User" class="nav-link" >Manage User</Link>
          </li>
          <li>
            <Link to="/superadmin/HotelList" class="nav-link" >Manage Hotel</Link>
          </li>
          <li>
            <Link to="/superadmin/FlightList" class="nav-link" >Manage Flight</Link>
          </li>
           <li>
            <Link to="/" class="nav-link float-right" >Logout</Link>
          </li>
        </ul>
        </div>

</nav>
<Outlet />
          </>
               
        );
    
}

export default NavBarSa;