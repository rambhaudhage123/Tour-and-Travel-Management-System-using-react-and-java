import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import FlightService from '../../../apis/FlightService';
import NavBarSa from '../NavBarSa';

const AddBook = () => {
  const navigate = useNavigate();
  const [toUpdateFlight, settoUpdateFlight] = useState({
    code:'',
    arrival:'',
    arrivalTime:'',
    depart:'',
    departTime:'',
    fromCity:'',
    price:2500,
    toCity:'',
    flightImg:','
  });

  const handlerChange = (event) => {
    const name = event.target.name;
    settoUpdateFlight({ ...toUpdateFlight, [name]: event.target.value });
  }

  const handleSubmit = (event) => {
    event.preventDefault();
 handletimearrival();
 handletimedepart();

FlightService.addFlight(toUpdateFlight);
    // UserService.addHotel(toUpdateFlight);
    settoUpdateFlight({
      code:'',
      arrival:'',
      arrivalTime:'',
      depart:'',
      departTime:'',
      fromCity:'',
      price:0,
      toCity:'',
      flightImg:','
    })
    navigate('/superadmin/FlightList')
  }
  const handletimearrival=()=>{
    var date=toUpdateFlight.arrivalTime;

                var hours=date.substr(0, 2);
                var minutes =date.substr(3, 2);
                // Check whether AM or PM
                var newformat = hours >= 12 ? 'PM' : 'AM'; 
                
                // Find current hour in AM-PM Format
                hours = hours % 12; 
                
                // To display "0" as "12"
                hours = hours ? hours : 12; 
                minutes = minutes < 10 ? '0' + minutes : minutes;
                
                var newdate=hours + ':' + minutes + ' ' + newformat;
         
  toUpdateFlight.arrivalTime=newdate;
  }
  const handletimedepart=()=>{
    var date=toUpdateFlight.departTime;

                var hours=date.substr(0, 2);
                var minutes =date.substr(3, 2);
                // Check whether AM or PM
                var newformat = hours >= 12 ? 'PM' : 'AM'; 
                
                // Find current hour in AM-PM Format
                hours = hours % 12; 
                
                // To display "0" as "12"
                hours = hours ? hours : 12; 
                minutes = minutes < 10 ? '0' + minutes : minutes;
                
                var newdate=hours + ':' + minutes + ' ' + newformat;
  toUpdateFlight.departTime=newdate;
  }

  return (
    <><NavBarSa></NavBarSa>
    <h1 class="display-4 text-center">Add Flight</h1>
      <form onSubmit={handleSubmit}>
        <div className="container-sm border mt-4 rounded">
          <div className="form-group mt-4">
            <label htmlFor="hotelName">Flight code</label>
            <input type="text" name="code" value={toUpdateFlight.code} onChange={handlerChange} required="required" placeholder='Enter Flight code' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="phoneNo">arrival Date</label>
            <input type="date" name="arrival" value={toUpdateFlight.arrival} onChange={handlerChange} required="required" placeholder='Enter Arrival date' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="location">arrival Time</label>
            <input type="time" name="arrivalTime" value={toUpdateFlight.arrivalTime} onChange={handlerChange} required="required" placeholder='Enter Arrival Time' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="city">departure Date</label>
            <input type="date" name="depart" value={toUpdateFlight.depart} onChange={handlerChange}  required="required" placeholder='Enter Depart date' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="rating">Departure Time</label>
            <input type="time" name="departTime" value={toUpdateFlight.departTime}onChange={handlerChange} required="required" placeholder='Enter Depart time' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="noOfRooms">From</label>
            <select type="text" name="fromCity" value={toUpdateFlight.fromCity} onChange={handlerChange} required="required" placeholder='From City' className="form-select">
            <option selected value="">Select Arrival city</option>
                      <option value="delhi-del">Delhi</option>
                      <option value="mumbai-bom">Mumbai</option>
                      <option value="bengalore-bng">Bangalore</option>
                      <option value="hyderabad-hyd">Hyderabad</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="roomid">To</label>
            <select type="text" name="toCity" value={toUpdateFlight.toCity} onChange={handlerChange} required="required" placeholder='From City' className="form-select">
            <option selected value="">Select Arrival city</option>
                      <option value="delhi-del">Delhi</option>
                      <option value="mumbai-bom">Mumbai</option>
                      <option value="bengalore-bng">Bangalore</option>
                      <option value="hyderabad-hyd">Hyderabad</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="img">Price</label>
            <input type="number" name="price" value={toUpdateFlight.price} onChange={handlerChange} required="required" placeholder='Enter price ' className="form-control"></input>
          </div>
          <div className="form-group">
            <label htmlFor="about">Image Url</label>
            <input type="text" name="flightImg" value={toUpdateFlight.flightImg} onChange={handlerChange} required="required" placeholder='Enter Image Url' className="form-control"></input>
          </div>
          <div className="form-group text-center mb-4">
            <input type="submit" value="Add Flight" className="btn btn-primary w-50 mt-2" />
          </div>
        </div>
      </form>
    </>
  )
}

export default AddBook