import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';

import UserService from'../../../apis/UserService'
import NavBarSa from '../NavBarSa';

const AdminList = () => {
    const navigate = useNavigate();
    const [Users, setUsers] = useState([]);
    const [toUpdateUser, settoUpdateUser] = useState({
    user_id:'',
        fullName:'',
        username:'',
        password:'',
        role:'ADMIN',
        status:0
    });

    useEffect(() => {
        UserService.getAdmins().then((response) => {
            setUsers(response.data)
        });
    }, []);

    const handlerChange = (event) => {
        const name = event.target.name;
        settoUpdateUser({ ...toUpdateUser, [name]: event.target.value });
    }

    return (
        <>
   <h1 class="display-4 text-center mt-3">Manage Admin</h1>
        <div>
        <button type="button" onClick={() => navigate("/superadmin/addAdmin") }class="btn btn-primary ms-5">Add Admin</button>
        </div>  <div className="mt-5 p-4">
                <table className="table table-striped">
                    <thead className="table-dark">
                        <tr className="text-center">
                        <th scope="col">Full Name</th>
        <th >Username</th>
        <th >Password</th>
        <th >Actions</th>
                        </tr>
                    </thead>
                    <tbody className="tbody">
                        {
                            Users.map(User => {
                                return (
                                    <tr className="text-center" key={User.user_id}>

<td>{User.fullName}</td>
    <td>{User.username}</td>
    <td>{User.password}</td>
    <td>
        <button type="button" class="btn btn-primary mx-1" data-bs-toggle="modal" data-bs-target="#updateBookModal" onClick={(event)=>settoUpdateUser(User)}>Edit</button>
        <button type="button" class="btn btn-secondary mx-1" onClick={()=> UserService.deleteUser(User.user_id)}>Delete</button>
        {
}
    </td>
                                  

                                    </tr>
                                )
                            })
                        }
                    </tbody >
                </table >
            </div >






            <div className="modal fade" id="updateBookModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Update Admin</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            <form onSubmit={() => UserService.updateUser(toUpdateUser.user_id,toUpdateUser)}>
                                <div className="form-group">
                                    <label htmlFor="hotelName">Full Name</label>
                                    <input type="text" name="fullName" value={toUpdateUser.fullName} onChange={handlerChange} required="required" placeholder='Enter Full Name' className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="phoneNo">Username</label>
                                    <input type="email" name="username" value={toUpdateUser.username} onChange={handlerChange} required="required" placeholder='Enter Username' className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="location">Password</label>
                                    <input type="text" name="password" value={toUpdateUser.password} onChange={handlerChange} required="required" placeholder='Enter Password'className="form-control"></input>
                                </div>
                
                                <div className="form-group text-center">
                                    <button type="submit" className="btn btn-primary w-40 mt-2" data-bs-dismiss="modal">Save</button>
                                    <button type="button" class="btn btn-secondary mx-1" className="btn btn-primary w-40 mt-2" data-bs-dismiss="modal">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AdminList