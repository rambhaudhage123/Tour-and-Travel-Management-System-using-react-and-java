import React, { useEffect, useState } from 'react'

import UserService from'../../../apis/UserService'
import NavBarSa from '../NavBarSa';
import { useNavigate } from 'react-router-dom';
const BookList = () => {
    const navigate = useNavigate();
    const [Hotels, setHotels] = useState([]);
    const [toUpdateHotel, settoUpdateHotel] = useState({
        hotel_id:'',
        hotelName: '',
        phoneNo: '',
        location: '',
        city: '',
        rating: '',
        noOfRooms: '',
        room_id: '',
        image: '',
        about: ''
    });

    useEffect(() => {
        UserService.getAllHotels().then((response) => {
            setHotels(response.data)
        });
    }, []);

    const handlerChange = (event) => {
        const name = event.target.name;
        settoUpdateHotel({ ...toUpdateHotel, [name]: event.target.value });
    }

    return (
        <>
            <NavBarSa></NavBarSa>
            <h1 class="display-4 text-center mt-3">Manage Hotel</h1>
        <div>
        <button type="button" onClick={() => navigate("/superadmin/addHotel") }class="btn btn-primary ms-5">Add Hotel</button>
        </div>  
             
            <div className="mt-5 p-4">
                <table className="table table-striped">
                    <thead className="table-dark">
                        <tr className="text-center">
                            <th >Hotel Name</th>
                            <th >phone No</th>
                            <th >Location</th>
                            <th >City</th>
                            <th >Rating</th>
                            <th >No. of Roooms</th>
                            <th >room_id</th>
                            <th >Image</th>
                            <th style={{ width: "120px" }}>About</th>
                            <th >Actions</th>
                        </tr>
                    </thead>
                    <tbody className="tbody">
                        {
                            Hotels.map(Hotels => {
                                return (
                                    <tr className="text-center" key={Hotels.hotel_id}>

                                        {/* <td><button data-bs-toggle="modal" data-bs-target="#updateBookModal" onClick={() => setToUpdateBook(book)} type="button" className="btn btn-primary">Edit Price</button></td>
                                        <td><button onClick={() => deleteBook(book.isbn)} type="button" className="btn btn-danger">Remove</button></td> */}
                                        <td>{Hotels.hotelName}</td>
                                        <td>{Hotels.phoneNo}</td>
                                        <td>{Hotels.location}</td>
                                        <td>{Hotels.city}</td>
                                        <td>{Hotels.rating}</td>
                                        <td>{Hotels.noOfRooms}</td>
                                        <td>{Hotels.room_id}</td>
                                        <td><img width="2px" height="2px" src={Hotels.image}></img></td>
                                        <td>{Hotels.about}</td>
                                        <td>
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#updateBookModal" class="btn btn-primary mx-1" onClick={(event) => settoUpdateHotel(Hotels)}>Edit</button>
                                            <button type="button" class="btn btn-secondary mx-1" onClick={() => UserService.deleteHotel(Hotels.hotel_id)}>Delete</button>
                                        </td>

                                    </tr>
                                )
                            })
                        }
                    </tbody >
                </table >
            </div >






            <div className="modal fade" id="updateBookModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Update Hotel</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            <form onSubmit={() => UserService.updateHotel(toUpdateHotel.hotel_id,toUpdateHotel)}>
                                <div className="form-group">
                                    <label htmlFor="hotelName">Hotel Name</label>
                                    <input type="text" name="hotelName" value={toUpdateHotel.hotelName} onChange={handlerChange} required="required" placeholder='Enter hotel name' className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="phoneNo">Hotel phoneNo</label>
                                    <input type="text" name="phoneNo" value={toUpdateHotel.phoneNo} onChange={handlerChange} required="required" placeholder='Enter hotel name' className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="location">Hotel Location</label>
                                    <input type="text" name="location" value={toUpdateHotel.location} onChange={handlerChange} required="required" placeholder='Enter area'className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="city">Hotel city</label>
                                    <input type="text" name="city" value={toUpdateHotel.city} onChange={handlerChange} required="required" placeholder='Enter area'className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="rating">Hotel rating</label>
                                    <input type="range" min="0" max="5" step="0.5" name="rating" value={toUpdateHotel.rating} onChange={handlerChange} required="required" placeholder='Enter rating' className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="noOfRooms">No of Rooms</label>
                                    <input type="number" name="noOfRooms" value={toUpdateHotel.noOfRooms} onChange={handlerChange} required="required" placeholder='Enter no. of room 'className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="roomid">Price</label>
                                    <input type="number" name="room_id" value={toUpdateHotel.room_id} onChange={handlerChange} required="required" placeholder='Enter room id'className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="img">image url</label>
                                    <input type="text" name="image" value={toUpdateHotel.image} onChange={handlerChange} required="required" placeholder='Enter price 'className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="about">about</label>
                                    <input type="text" name="about" value={toUpdateHotel.about} onChange={handlerChange} required="required" placeholder='Enter about'className="form-control"></input>
                                </div>
                                <div className="form-group text-center">
                                    <button type="submit" className="btn btn-primary w-40 mt-2" data-bs-dismiss="modal">Save</button>
                                    <button type="button" class="btn btn-secondary mx-1" className="btn btn-primary w-40 mt-2" data-bs-dismiss="modal">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default BookList